ARXIV SOURCE PACKAGE

Title: Energy Capture, Agency, and Planetary Entropy: An Exploratory Spatial Evolutionary Model
Author: Praveen Chandrahas
Version 1.1, revised 23 November 2026 (version 1.0: 16 November 2026)

Suggested primary category: physics.bio-ph
Suggested cross-list: q-bio.PE

This archive contains the LaTeX manuscript, BibTeX database, compiled bibliography,
and all five figure files. The PDF is supplied separately as the preprint artifact.

Build with a standard TeX Live installation:

  pdflatex main.tex
  pdflatex main.tex

The included main.bbl is already generated, so BibTeX is not required to reproduce
the supplied bibliography. To regenerate it after editing references:

  bibtex main
  pdflatex main.tex
  pdflatex main.tex

The document uses standard LaTeX packages: geometry, newtxtext/newtxmath,
microtype, amsmath, graphicx, booktabs, tabularx, siunitx, natbib, hyperref,
enumitem, caption, subcaption, float, and xcolor.

This package has not been submitted to arXiv and has no arXiv identifier.
